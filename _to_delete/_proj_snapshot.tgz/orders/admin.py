from django.contrib import admin
from .models import Order, OrderItem, OrderStatus, OrderStatusHistory

# Регистрируем статусы заказов
@admin.register(OrderStatus)
class OrderStatusAdmin(admin.ModelAdmin):
    list_display = ['name', 'color', 'order', 'is_active']
    list_editable = ['order']
    ordering = ['order']

# Регистрируем заказы
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['order_number', 'user', 'status', 'total_amount', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['order_number', 'user__email']
    readonly_fields = ['order_number', 'created_at']

# Регистрируем позиции заказов
@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['order', 'product_name', 'price', 'quantity']

# Регистрируем историю статусов
@admin.register(OrderStatusHistory)
class OrderStatusHistoryAdmin(admin.ModelAdmin):
    list_display = ['order', 'status', 'changed_at']
    readonly_fields = ['changed_at']